import os
from pypdf import PdfWriter, PdfReader


def merge_pdfs(pdf_files, output_path):

    if len(pdf_files) < 2:
        raise ValueError("Please select at least two PDF files.")

    output_path = os.path.abspath(output_path)

    # Prevent overwriting source PDFs
    source_paths = [os.path.abspath(f) for f in pdf_files]

    if output_path in source_paths:
        raise ValueError("Output cannot overwrite an original PDF.")

    writer = PdfWriter()

    try:
        for pdf in pdf_files:

            if not os.path.exists(pdf):
                raise FileNotFoundError(f"File not found: {pdf}")

            if not pdf.lower().endswith(".pdf"):
                raise ValueError(f"Invalid PDF file: {pdf}")

            reader = PdfReader(pdf, strict=False)

            if reader.is_encrypted:
                raise ValueError(
                    f"Password-protected PDF detected: {os.path.basename(pdf)}"
                )

            if len(reader.pages) == 0:
                raise ValueError(
                    f"PDF contains no pages: {os.path.basename(pdf)}"
                )

            writer.append(reader)

        with open(output_path, "wb") as output:
            writer.write(output)

        return output_path

    finally:
        writer.close()