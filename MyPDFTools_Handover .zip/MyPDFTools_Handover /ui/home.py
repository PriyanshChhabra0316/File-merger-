import customtkinter as ctk
from tkinter import filedialog, messagebox
import os

from modules.pdf_merger import merge_pdfs


class Home(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.title("MyPDFTools")
        self.geometry("800x600")
        self.minsize(650, 500)

        self.files = []

        self.create_interface()

    def create_interface(self):

        # Header
        ctk.CTkLabel(
            self,
            text="MyPDFTools",
            font=("Arial", 32, "bold")
        ).pack(pady=(30, 5))

        ctk.CTkLabel(
            self,
            text="Your personal PDF workspace",
            font=("Arial", 15)
        ).pack(pady=(0, 25))

        # Main container
        self.container = ctk.CTkFrame(self)
        self.container.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=10
        )

        # Add files
        ctk.CTkButton(
            self.container,
            text="+ Add PDF Files",
            height=45,
            command=self.add_files
        ).pack(pady=20)

        self.count_label = ctk.CTkLabel(
            self.container,
            text="No files selected"
        )
        self.count_label.pack()

        # File list
        self.file_frame = ctk.CTkScrollableFrame(
            self.container,
            height=280
        )
        self.file_frame.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=15
        )

        # Bottom buttons
        button_frame = ctk.CTkFrame(
            self.container,
            fg_color="transparent"
        )
        button_frame.pack(pady=20)

        ctk.CTkButton(
            button_frame,
            text="Clear All",
            fg_color="gray",
            command=self.clear_files
        ).pack(side="left", padx=10)

        ctk.CTkButton(
            button_frame,
            text="Merge PDFs",
            width=160,
            height=40,
            command=self.merge
        ).pack(side="left", padx=10)

    # ADD PDF FILES

    def add_files(self):

        selected = filedialog.askopenfilenames(
            filetypes=[("PDF Files", "*.pdf")]
        )

        for file in selected:
            if file not in self.files:
                self.files.append(file)

        self.refresh_files()

    # REFRESH FILE LIST

    def refresh_files(self):

        for widget in self.file_frame.winfo_children():
            widget.destroy()

        self.count_label.configure(
            text=f"{len(self.files)} PDF file(s) selected"
            if self.files else "No files selected"
        )

        for index, file in enumerate(self.files):

            row = ctk.CTkFrame(self.file_frame)
            row.pack(fill="x", pady=5)

            ctk.CTkLabel(
                row,
                text=f"{index + 1}. {os.path.basename(file)}",
                anchor="w"
            ).pack(
                side="left",
                padx=10,
                pady=10,
                fill="x",
                expand=True
            )

            ctk.CTkButton(
                row,
                text="↑",
                width=35,
                command=lambda i=index: self.move_file(i, -1)
            ).pack(side="left", padx=2)

            ctk.CTkButton(
                row,
                text="↓",
                width=35,
                command=lambda i=index: self.move_file(i, 1)
            ).pack(side="left", padx=2)

            ctk.CTkButton(
                row,
                text="✕",
                width=35,
                fg_color="#A83232",
                command=lambda i=index: self.remove_file(i)
            ).pack(side="left", padx=5)

    # REORDER FILES

    def move_file(self, index, direction):

        new_index = index + direction

        if 0 <= new_index < len(self.files):

            self.files[index], self.files[new_index] = (
                self.files[new_index],
                self.files[index]
            )

        self.refresh_files()

    # REMOVE INDIVIDUAL FILE

    def remove_file(self, index):

        self.files.pop(index)
        self.refresh_files()

    # CLEAR ALL FILES

    def clear_files(self):

        self.files.clear()
        self.refresh_files()
        self.update_idletasks()

    # MERGE PDFS

    def merge(self):

        if len(self.files) < 2:

            messagebox.showwarning(
                "Warning",
                "Please select at least two PDF files."
            )
            return

        output = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            initialfile="Merged_Document.pdf",
            filetypes=[("PDF Files", "*.pdf")]
        )

        if not output:
            return

        try:

            merge_pdfs(self.files, output)

            messagebox.showinfo(
                "Success",
                f"PDFs merged successfully!\n\n{output}"
            )

        except Exception as error:

            messagebox.showerror(
                "Merge Failed",
                str(error)
            )


if __name__ == "__main__":

    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")

    app = Home()
    app.mainloop()